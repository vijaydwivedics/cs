# flowupload-nextcloud-v15
In flowupload , When upload duplicate file to crate copy of file or replace

<img src="https://github.com/vijaydwivedics/flowupload-nextcloud-v15/blob/master/apps/flowupload/img/img.png" alt="img.png">

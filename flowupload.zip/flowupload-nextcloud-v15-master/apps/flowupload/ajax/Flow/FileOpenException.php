<?php

namespace Flow;

class FileOpenException extends \Exception
{
}

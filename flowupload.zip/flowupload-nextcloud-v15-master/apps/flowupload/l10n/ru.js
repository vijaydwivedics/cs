OC.L10N.register(
  "flowupload", {
    "Name" : "Имя",
    "FlowUpload" : "FlowUpload",
    "Select File": "Выбрать файл",
    "Select Folder": "Выбрать папку",
    "... or drag and drop your files here" : "... или перетащите сюда ваши файлы",
    "Transfers" : "Передачи",
    "Upload" : "Загрузить",
    "Pause" : "Пауза",
    "Cancel" : "Отмена",
    "Uploading" : "Загрузка",
    "Size" : "Размер",
    "Progress" : "Прогресс",
    "Retry" : "Повтор",
    "Completed" : "Завершено",
    "The files will be saved in your home directory." : "Файлы будут сохранены в вашем домашнем каталоге"
  },
  "nplurals=2; plural=(n > 1);"
);

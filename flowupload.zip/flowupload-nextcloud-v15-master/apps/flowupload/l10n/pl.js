OC.L10N.register(
  "flowupload", {
    "FlowUpload" : "Wyślij pliki",
    "Select File": "Wybierz plik",
    "Select Folder" : "Wybierz folder",
    "... or drag and drop your files here" : "... albo przeciągnij i upuść swoje pliki tutaj",
    "Transfers" : "Transfery",
    "Upload" : "Wyślij",
    "Pause" : "Wstrzymaj",
    "Cancel" : "Anuluj",
    "Uploading" : "Przesyłanie",
    "Size" : "Rozmiar",
    "Progress" : "Postęp",
    "Retry" : "Ponów",
    "Resume" : "Wznów",
    "Completed" : "Ukończone",
    "The files will be saved in your home directory." : "Pliki zostaną zapisane w twoim katalogu domowym."
  },
  "nplurals=2; plural=(n > 1);"
);

OC.L10N.register(
  "flowupload", {
    "FlowUpload" : "Odeslat soubory",
    "Select File": "Vyber Soubor",
    "Select Folder" : "Vyber Adresář",
    "... or drag and drop your files here" : "... a nebo přetáhni soubory sem",
    "Transfers" : "Přenosy",
    "Upload" : "Nahrát",
    "Pause" : "Pauza",
    "Cancel" : "Zrušit",
    "Uploading" : "Nahrávání",
    "Size" : "Velikost",
    "Name" : "Jméno",
    "Progress" : "Průběh",
    "Retry" : "Znovu",
    "Resume" : "Pokračuj",
    "Completed" : "Hotovo",
    "The files will be saved in your home directory." : "Soubory budou uloženy do vašeho domovského adresáře."
  },
  "nplurals=2; plural=(n > 1);"
);

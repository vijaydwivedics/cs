OC.L10N.register(
  "flowupload", {
    "FlowUpload" : "Flowupload",
    "Select File": "Datei auswählen",
    "Select Folder": "Ordner auswählen",
    "... or drag and drop your files here" : "... oder ziehen Sie Ihre Dateien hierher",
    "Transfers" : "Übertragungen",
    "Upload" : "Hochladen",
    "Pause" : "Pause",
    "Cancel" : "Abbrechen",
    "Uploading" : "Wird hochgeladen",
    "Size" : "Dateigröße",
    "Progress" : "Fortschritt",
    "Retry" : "Wiederholen",
    "Completed" : "Fertig",
    "The files will be saved in your home directory." : "Die Dateien werden in Ihrem Account im Ordner flowupload gespeichert."
  },
  "nplurals=2; plural=(n > 1);"
);

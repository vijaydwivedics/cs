OC.L10N.register(
  "flowupload", {
    "FlowUpload" : "Subir Ficheros",
    "Select File": "Seleccionar fichero",
    "Select Folder": "Seleccionar carpeta",
    "... or drag and drop your files here" : "... o arrastra tus ficheros aquí",
    "Transfers" : "Transferencias",
    "Upload" : "Subir",
    "Name" : "Nombre",
    "Pause" : "Pausa",
    "Cancel" : "Descartar",
    "Uploading" : "Envíos en curso",
    "Size" : "Tamaño",
    "Progress" : "Progreso",
    "Retry" : "Reintentar",
    "Completed" : "Completado",
    "The files will be saved in your home directory" : "Los ficheros se subirán a tu directorio raíz"
  },
  "nplurals=2; plural=(n > 1);"
);

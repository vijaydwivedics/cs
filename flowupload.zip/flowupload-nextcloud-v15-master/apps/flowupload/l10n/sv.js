OC.L10N.register(
  "flowupload", {
    "FlowUpload" : "FlowUpload",
    "Select File": "Välj fil",
    "Select Folder": "Välj mapp",
      "... or drag and drop your files here" : "... eller dra och släpp dina filer här",
      "Transfers" : "Överföringar",
      "Upload" : "Ladda upp",
      "Pause" : "Pausa",
      "Cancel" : "Avbryt",
      "Uploading" : "Laddar upp",
      "Size" : "Storlek",
      "Progress" : "Framsteg",
      "Retry" : "Försök igen",
      "Completed" : "Färdig",
      "The files will be saved in your home directory." : "Dina filer kommer sparas i din hemkatalog"
  },
  "nplurals=2; plural=(n > 1);"
);
